(** [Uno] contains the cards of the game and their corresponding attributes, and 
    generates the randomized hands for each player, and the random start card.*)

(** Type [color] represents one out of the four possible Uno colors, otherwise 
    wild card/wild card draw 4/free card (Nocolor).   *)
type color = Red | Blue | Yellow | Green | NoColor

(** Type [special] represents a special ability of a Uno card.   *)
type special = WC | WCDF | DT | Skip | Reverse | NotSpecial | WCSH | Free

(** Type [card] represents a Uno card. [number] must be between 0 and 9, 
    invlusive.  [name] must be a valid Uno card name.  *)
type card = {
  name: string;
  number: int;
  color: color;
  special: special;
}

(** [cards] is a list of all the Uno cards. *)
let cards  = [
  {name= "Red 0"; number =  0 ; color = Red; special= NotSpecial};
  {name= "Blue 0";number =  0 ; color =  Blue; special= NotSpecial};
  {name ="Green 0";number =  0 ; color =  Green; special= NotSpecial};
  {name ="Yellow 0"; number =  0 ; color =  Yellow; special= NotSpecial};
  {name= "Red 1" ; number =  1 ; color =  Red; special= NotSpecial};
  {name= "Blue 1"; number =  1 ; color =  Blue; special= NotSpecial};
  {name= "Green 1";number =  1 ; color =  Green; special= NotSpecial};
  {name = "Yellow 1" ; number =  1 ; color =  Yellow; special= NotSpecial};
  {name = "Red 2" ; number =  2 ; color =  Red; special= NotSpecial};
  {name = "Red 3" ; number =  3 ; color =  Red; special= NotSpecial};
  {name = "Red 4" ; number =  4 ; color =  Red; special= NotSpecial};
  {name = "Red 5" ; number =  5 ; color =  Red; special= NotSpecial};
  {name = "Red 6" ; number =  6 ; color =  Red; special= NotSpecial};
  {name = "Blue 2" ; number =  2 ; color =  Blue; special= NotSpecial};
  {name = "Blue 3" ; number =  3 ; color =  Blue; special= NotSpecial};
  {name = "Blue 4" ; number =  4 ; color =  Blue; special= NotSpecial};
  {name = "Blue 5" ; number =  5 ; color =  Blue; special= NotSpecial};
  {name = "Blue 6" ; number =  6 ; color =  Blue; special= NotSpecial};
  {name = "Green 2" ; number =  2 ; color =  Green; special= NotSpecial};
  {name = "Green 3" ; number =  3 ; color =  Green; special= NotSpecial};
  {name = "Green 4" ; number =  4 ; color =  Green; special= NotSpecial};
  {name = "Green 5" ; number =  5 ; color =  Green; special= NotSpecial};
  {name = "Green 6" ; number =  6 ; color =  Green; special= NotSpecial};
  {name = "Yellow 2" ; number =  2 ; color =  Yellow; special= NotSpecial};
  {name = "Yellow 3" ; number =  3 ; color =  Yellow; special= NotSpecial};
  {name = "Yellow 4" ; number =  4 ; color =  Yellow; special= NotSpecial};
  {name = "Yellow 5" ; number =  5 ; color =  Yellow; special= NotSpecial};
  {name = "Yellow 6" ; number =  6 ; color =  Yellow; special= NotSpecial};
  {name= "Red 1" ; number =  1 ; color =  Red; special= NotSpecial};
  {name= "Blue 1"; number =  1 ; color =  Blue; special= NotSpecial};
  {name= "Green 1";number =  1 ; color =  Green; special= NotSpecial};
  {name = "Yellow 1" ; number =  1 ; color =  Yellow; special= NotSpecial};
  {name = "Red 2" ; number =  2 ; color =  Red; special= NotSpecial};
  {name = "Red 3" ; number =  3 ; color =  Red; special= NotSpecial};
  {name = "Red 4" ; number =  4 ; color =  Red; special= NotSpecial};
  {name = "Red 5" ; number =  5 ; color =  Red; special= NotSpecial};
  {name = "Red 6" ; number =  6 ; color =  Red; special= NotSpecial};
  {name = "Blue 2" ; number =  2 ; color =  Blue; special= NotSpecial};
  {name = "Blue 3" ; number =  3 ; color =  Blue; special= NotSpecial};
  {name = "Blue 4" ; number =  4 ; color =  Blue; special= NotSpecial};
  {name = "Blue 5" ; number =  5 ; color =  Blue; special= NotSpecial};
  {name = "Blue 6" ; number =  6 ; color =  Blue; special= NotSpecial};
  {name = "Green 2" ; number =  2 ; color =  Green; special= NotSpecial};
  {name = "Green 3" ; number =  3 ; color =  Green; special= NotSpecial};
  {name = "Green 4" ; number =  4 ; color =  Green; special= NotSpecial};
  {name = "Green 5" ; number =  5 ; color =  Green; special= NotSpecial};
  {name = "Green 6" ; number =  6 ; color =  Green; special= NotSpecial};
  {name = "Yellow 2" ; number =  2 ; color =  Yellow; special= NotSpecial};
  {name = "Yellow 3" ; number =  3 ; color =  Yellow; special= NotSpecial};
  {name = "Yellow 4" ; number =  4 ; color =  Yellow; special= NotSpecial};
  {name = "Yellow 5" ; number =  5 ; color =  Yellow; special= NotSpecial};
  {name = "Yellow 6" ; number =  6 ; color =  Yellow; special= NotSpecial};
  {name = "Red 6"; number =  6; color =  Red; special =  NotSpecial;};
  {name = "Blue 6"; number =  6; color =  Blue; special =  NotSpecial;} ;
  {name = "Green 6"; number =  6; color =  Green; special =  NotSpecial;};
  {name = "Yellow 6"; number =  6; color =  Yellow; special =  NotSpecial;};
  {name = "Red 7"; number =  7; color =  Red; special =  NotSpecial;};
  {name = "Blue 7"; number =  7; color =  Blue; special =  NotSpecial;} ;
  {name = "Green 7"; number =  7; color =  Green; special =  NotSpecial;};
  {name = "Yellow 7"; number =  7; color =  Yellow; special =  NotSpecial;};
  {name = "Red 8"; number =  8; color =  Red; special =  NotSpecial;};
  {name = "Blue 8"; number =  8; color =  Blue; special =  NotSpecial;} ;
  {name = "Green 8"; number =  8; color =  Green; special =  NotSpecial;};
  {name = "Yellow 8"; number =  8; color =  Yellow; special =  NotSpecial;};
  {name = "Red 9"; number =  9; color =  Red; special =  NotSpecial;};
  {name = "Blue 9"; number =  9; color =  Blue; special =  NotSpecial;} ;
  {name = "Green 9"; number =  9; color =  Green; special =  NotSpecial;};
  {name = "Yellow 9"; number =  9; color =  Yellow; special =  NotSpecial;};
  {name = "Red 6"; number =  6; color =  Red; special =  NotSpecial;};
  {name = "Blue 6"; number =  6; color =  Blue; special =  NotSpecial;} ;
  {name = "Green 6"; number =  6; color =  Green; special =  NotSpecial;};
  {name = "Yellow 6"; number =  6; color =  Yellow; special =  NotSpecial;};
  {name = "Red 7"; number =  7; color =  Red; special =  NotSpecial;};
  {name = "Blue 7"; number =  7; color =  Blue; special =  NotSpecial;} ;
  {name = "Green 7"; number =  7; color =  Green; special =  NotSpecial;};
  {name = "Yellow 7"; number =  7; color =  Yellow; special =  NotSpecial;};
  {name = "Red 8"; number =  8; color =  Red; special =  NotSpecial;};
  {name = "Blue 8"; number =  8; color =  Blue; special =  NotSpecial;} ;
  {name = "Green 8"; number =  8; color =  Green; special =  NotSpecial;};
  {name = "Yellow 8"; number =  8; color =  Yellow; special =  NotSpecial;};
  {name = "Red 9"; number =  9; color =  Red; special =  NotSpecial;};
  {name = "Blue 9"; number =  9; color =  Blue; special =  NotSpecial;} ;
  {name = "Green 9"; number =  9; color =  Green; special =  NotSpecial;};
  {name = "Yellow 9"; number =  9; color =  Yellow; special =  NotSpecial;};
  {name = "Red Draw 2"; number =  -1; color =  Red; special =  DT};
  {name = "Red Draw 2"; number =  -1; color =  Red; special =  DT};
  {name = "Blue Draw 2"; number =  -1; color =  Blue; special =  DT};
  {name = "Blue Draw 2"; number =  -1; color =  Blue; special =  DT};
  {name = "Green Draw 2"; number =  -1; color =  Green; special =  DT};
  {name = "Green Draw 2"; number =  -1; color =  Green; special =  DT};
  {name = "Yellow Draw 2"; number =  -1; color =  Yellow; special =  DT};
  {name = "Yellow Draw 2"; number =  -1; color =  Yellow; special =  DT};
  {name = "Red Skip"; number =  -2; color =  Red; special =  Skip};
  {name = "Red Skip"; number =  -2; color =  Red; special =  Skip};
  {name = "Blue Skip"; number =  -2; color =  Blue; special =  Skip};
  {name = "Blue Skip"; number =  -2; color =  Blue; special =  Skip};
  {name = "Green Skip"; number =  -2; color =  Green; special =  Skip};
  {name = "Green Skip"; number =  -2; color =  Green; special =  Skip};
  {name = "Yellow Skip"; number =  -2; color =  Yellow; special =  Skip};
  {name = "Yellow Skip"; number =  -2; color =  Yellow; special =  Skip};
  {name = "Red Reverse"; number =  -3; color =  Red; special =  Reverse};
  {name = "Red Reverse"; number =  -3; color =  Red; special =  Reverse};
  {name = "Blue Reverse"; number =  -3; color =  Blue; special =  Reverse};
  {name = "Blue Reverse"; number =  -3; color =  Blue; special =  Reverse};
  {name = "Green Reverse"; number =  -3; color =  Green; special =  Reverse};
  {name = "Green Reverse"; number =  -3; color =  Green; special =  Reverse};
  {name = "Yellow Reverse"; number =  -3; color =  Yellow; special =  Reverse};
  {name = "Yellow Reverse"; number =  -3; color =  Yellow; special =  Reverse};
  {name = "Wild Card"; number =  -4; color =  NoColor; special =  WC};
  {name = "Wild Card"; number = -4; color = NoColor; special =  WC};
  {name = "Wild Card"; number = -4; color = NoColor; special =  WC};
  {name = "Wild Card"; number = -4; color = NoColor; special =  WC};
  {name = "Wild Card Draw 4"; number = -5; color = NoColor; special =  WCDF};
  {name = "Wild Card Draw 4"; number = -5; color = NoColor; special =  WCDF};
  {name = "Wild Card Draw 4"; number = -5; color = NoColor; special =  WCDF};
  {name = "Wild Card Draw 4"; number = -5; color = NoColor; special =  WCDF};
  {name = "Free Card"; number = -7; color = NoColor; special = Free};
  {name = "Free Card"; number = -7; color = NoColor; special = Free};
  {name = "Wild Card Swap Hands"; number = -8; color = NoColor; special = WCSH};
  {name = "Wild Card Swap Hands"; number = -8; color = NoColor; special = WCSH};
  {name = "Blue"; number = -6; color = Blue; special = NotSpecial};
  {name = "Red"; number = -6; color = Red; special = NotSpecial};
  {name = "Yellow"; number = -6; color = Yellow; special = NotSpecial};
  {name = "Green"; number = -6; color = Green; special = NotSpecial};

]

(** [draw_random cards] is a randomly selected card from [cards]. *)
let rec draw_random (cards:card list) num_of_cards_to_draw range card_list=
  match num_of_cards_to_draw with 
  | 0 -> card_list
  | _ -> 
    Random.self_init ();
    let rand= Random.int range in
    let draw= List.nth cards rand in 
    (draw_random cards (num_of_cards_to_draw-1) range (draw::card_list))

(** [start_card cards] is a randomly selected starter card, to start the game,
    from [cards]. *)
let rec start_card cards=
  draw_random cards 1 83 []

(** [initial_cards card_list init_cards] is a list of 7 randomly selected 
    cards from [card_list] that are added to [init_cards]. *)
let initial_cards card_list =
  (draw_random card_list 7 (118) [])

(** [card_name card] is the name of [card]. *)
let card_name card =
  card.name

(** [card_number card] is the number of [card]. *)
let card_number card=
  card.number

(** [card_color card] is the color of [card]. *)
let card_color card =
  card.color

(** [card_special card] is the special ability of [card]. *)
let card_special card=
  card.special

(** [card_list_to_card_name_list card_list] is a list of cards in [card_list].*)
let rec card_list_to_card_name_list card_list = 
  match card_list with
  | [] -> []
  | h::t -> card_name h :: card_list_to_card_name_list t

(** [card_name_to_color] is the color that corresponds to [name] in the list 
    [cards]. *)
let rec card_name_to_color name cards= 
  match cards with 
  |[] -> failwith "card not found"
  |h::t -> if h.name= name then h.color else card_name_to_color name t

(** [card_name_to_number name cards] is the number that corresponds to the 
    card [name] in the list [cards]. *)
let rec card_name_to_number name cards= 
  match cards with 
  |[] -> failwith "card not found"
  |h::t -> if h.name= name then h.number else card_name_to_number name t

(** [card_name_to_special name cards] is the name t *)
let rec card_name_to_special name cards=
  match cards with 
  | [] -> failwith "card not found"
  |h::t -> if h.name = name then h.special else card_name_to_special name t

(** [match_card_name_to_card name cards] is the card that corresponds to [name] 
    in the list [cards]. *)
let rec match_card_name_to_card name cards= 
  match cards with 
  | [] -> failwith "card not found"
  | h::t -> if h.name = name then h else match_card_name_to_card name t



