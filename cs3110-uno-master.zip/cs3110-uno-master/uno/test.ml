(** 
   Uno.ml test suite: Our approach for this module was to test the “getter” 
   functions and “translation” functions.  Getter functions are (card_name, 
   card_number, card_color, card_special), which gives the attributes of a certain 
   card. Translation functions are (card_list_to_card_name_list, card_name_to_color,
   card_name_to_number, card_name_to_special, match_card_name_to_card), which 
   takes a matches a certain attribute of a card to its corresponding other 
   attributes.  We omitted testing (start_card, initial_cards, draw_random) 
   because as these are randomly generated cards from the Uno deck, for the start 
   card and initial hands of the players.  This module was tested by OUNit, 
   and test cases were generated using black box testing, which was sufficient 
   for this module as all cards came from the same record, and we were just 
   testing the returning of the correct attributes. 

   Action.ml test suite: Our approach was to test all the functions, which were 
   (check_uno, no_empties, parse).  We tested if our system recognizes if someone 
   types uno after their command, and if they don’t in check_uno_test, and made 
   sure that no_empties gets ride of all empty strings in our parsed string list.
   We also tested parse, one of the most important functions in the game, for if 
   it accepts commands regardless of uppercase/lowercase, and correctly parses the 
   input following the command to a string list.  Additionally we tested if it 
   gives the right exception when a user types in an invalid command, or an 
   empty string. This shows that the corresponding guiding message will be shown.  
   We didn’t omit testing in this module.  This module was tested by OUnit, and 
   test cases were developed using both black box and glass box testing, as we 
   tested the correct parsing of the possbile game commands.

   Gamestate.ml test suite: Our approach was to create our own custom state, 
   without random cards that we can test the functionality of the different action 
   commands.  We tested the helper functions first, to make sure that these are 
   correct, as our game action functions employ these functions when returning the
   new state.  So, we tested (take_out_one, check_valid, cycle, and cycle_skip, 
   and whose_deck). This made sure that when a user drops a card, the system only
   takes out the first instance of the card from their deck, not all matching cards
   with the same name, and showed that our system was able to recognize a valid 
   drop (if the card being dropped has matching number/color as the current card) 
   except for wild cards, which is not checked as those cards can be dropped 
   whenever.  Cycle and cycle skip tests checked that for both game settings where 
   there is a computer player added and when there’s not, based on the direction 
   and current turn, the game advances to the correct player.  Whose_deck tests 
   showed correct matching of turn to player deck.  Because these helper functions 
   were tested, we know that in every game action method, players can only drop 
   valid cards, the turn will be updated correctly, and the corresponding effect 
   of the card will be applied to the correct deck (one instance of card_name is 
   removed from current player deck, and depending on effect, there can be cards
   added to the next players deck) .  To further prove correctness of our system, 
   we created custom states and passed them into the game action functions.  
   For drop (cards with no effect), we proved that all attributes of state update 
   as expected: current player who drops the card gets one instance of that card 
   removed from their deck,  other player’s decks remain the same, current card 
   updates to dropped card, and it advances to the next players turn. Direction, 
   numplayers, and game state stay the same.  For (draw/draw_two), we tested 
   that the length of the (current/next player, respectively) player gets 
   incremented by by the accurate number( 1, 2, respectively) , as we already
   tested that the turn accurately moves on to the next player (using cycle 
   and cycle skip, respectively), and all other attributes just stays the same. 
   For (skip/reverse), we just tested if the turn updates accurately, as the
    other attributes of states are the same as those in drop, which was already
   tested. For Wild Card, we tested that the current card gets updated to the
   corresponding color name that the user chooses, as the other attributes 
   have the same behavior as drop method, which has already been tested.  
   Because we know that the wild_card correctly makes the current_card the 
   color card that the user chooses, for wild card draw 4 we just test if the 
   next player has additional 4 cards added to their desk by getting the length, 
   like in draw 2.  We also tested the (vs_computer) by making sure that the 
   algorithm takes out the first valid card from a deck, else it draws.  
   Lastly, we tested the draw_two_uno by checking that this method adds two 
   cards to current player’s deck, as other attributes, again, have already been 
   testing in the cases above.  Only thing we omitted testing in Gamestate.ml 
   were attributes that share the same behavior, and had already been tested in 
   other game action function tests.  This module was tested by OUnit, and test
   cases were developed using black box and glass box testing, as we created 
   custom states and tested that dropping cards of all 6 types of special cards   
   (wild card,wild card draw 4, reverse, skip, draw 2, and not special) would
   return the correct state. 
   We think our test suite shows the correctness of our system as we proved that 
   the game state updates accurately for all attributes (direction, turn, 
   current card, and player hands) for a custom state with custom decks for all 
   the game actions, (drop, draw 2, reverse, skip, wild card, wild card draw 4), 
   and the difference between this and the real game is just the randomness of 
   the player hands.  We also made sure that players are only allowed to drop 
   valid cards, ones that match the current card on the deck, and that the 
   player turns cycle accurately.  We also tested if the vs mode accurately 
   drops a valid card in their deck, or draws if they don’t have one. Therefore, 
   we think that this shows that our game is correct.
*)

open OUnit2
open Uno
open Action
open Gamestate


(* red 1 *)
let red1 = List.nth Uno.cards 4
(*red 0*)
let red0 = List.nth Uno.cards 0
(*wildcard*)
let wildcard=List.nth Uno.cards 110
(* list with Red 1, blue draw 2, green skip, yellow reverse, wild card,wild card draw 4 *)
let cardlist1= (List.nth Uno.cards 4)::(List.nth Uno.cards 87)::(List.nth Uno.cards 96)::
               (List.nth Uno.cards 106)::(List.nth Uno.cards 110)::(List.nth Uno.cards 114)::[]
(* list with blue 1 , red 0, green draw 2; red skip; wild card draw 4; blue reverse *)
let cardlist2= List.nth Uno.cards 5::List.nth Uno.cards 0::List.nth Uno.cards 89::List.nth Uno.cards 92::
               List.nth Uno.cards 114::List.nth Uno.cards 103::List.nth Uno.cards 5::[]
let make_card_name_test
    (name: string)
    (card: Uno.card)
    (expected_output: string) =
  name >:: (fun _ -> 
      assert_equal (Uno.card_name card) (expected_output))

let make_card_number_test
    (name: string)
    (card: Uno.card)
    (expected_output: int) =
  name >:: (fun _ -> 
      assert_equal (Uno.card_number card) (expected_output))

let make_card_color_test
    (name: string)
    (card: Uno.card)
    (expected_output: color) =
  name >:: (fun _ -> 
      assert_equal (Uno.card_color card) (expected_output))

let make_card_special_test
    (name: string)
    (card: Uno.card)
    (expected_output: special) =
  name >:: (fun _ -> 
      assert_equal (Uno.card_special card) (expected_output))

let card_list_to_card_name_list_test
    (name:string)
    (card_list: card list)
    (expected_output: string list) =
  name >:: (fun _ -> 
      assert_equal (Uno.card_list_to_card_name_list card_list)  (expected_output))

let card_name_to_color_test
    (name1:string)
    (name: string)
    (cards: card list)
    (expected_output: color) =
  name1 >:: (fun _ -> 
      assert_equal (Uno.card_name_to_color name cards) (expected_output))

let card_name_to_number_test
    (name1:string)
    (name: string)
    (cards: card list)
    (expected_output: int) =
  name1 >:: (fun _ -> 
      assert_equal (Uno.card_name_to_number name cards)  (expected_output))

let card_name_to_special_test
    (name1:string)
    (name: string)
    (cards: card list)
    (expected_output: special) =
  name1 >:: (fun _ -> 
      assert_equal (Uno.card_name_to_special name cards)  (expected_output))

let match_card_name_to_card_test
    (name1:string)
    (name: string)
    (cards: card list)
    (expected_output: card) =
  name1 >:: (fun _ -> 
      assert_equal (Uno.match_card_name_to_card name cards)  (expected_output))


let uno_tests = 
  [
    make_card_name_test "testing card name" red1 "Red 1";
    make_card_number_test "testing card number" red1 1;
    make_card_special_test "testing card special" wildcard WC;
    card_list_to_card_name_list_test "testing all_card names" cardlist1 
      (["Red 1";"Blue Draw 2";"Green Skip"; "Yellow Reverse"; "Wild Card"; 
        "Wild Card Draw 4"]);
    card_name_to_color_test "testing name to color" "Red 1" Uno.cards Red;
    card_name_to_number_test "testing name to number" "Red 1" Uno.cards 1;
    card_name_to_special_test "testing name to speical" "Wild Card" Uno.cards WC;
    match_card_name_to_card_test "testing card name to card" "Wild Card"
      Uno.cards (List.nth Uno.cards 108)
  ]

let dropred1= ["drop"; ""; ""; "red"; "1"]
let no_empties_test
    (name:string)
    (cmdlist: string list)
    (acc: string list)
    (expected_output: string list) =
  name >:: (fun _ -> 
      assert_equal (Action.no_empties cmdlist acc)  (expected_output))

let parse_test
    (name:string)
    (str: string)
    (expected_output: action) =
  name >:: (fun _ -> 
      assert_equal (Action.parse str)  (expected_output))

let parse_test_exn
    (name:string)
    (str: string)
    (expected_output: exn) =
  name >:: (fun _ -> 
      assert_raises (CmdNotFound) (fun ()-> Action.parse str))

let parse_test_exn_empty
    (name:string)
    (str: string)
    (expected_output: exn) =
  name >:: (fun _ -> 
      assert_raises (Unavailable) (fun ()-> Action.parse str))

let check_uno_test  
    (name:string)
    (lst: string list)
    (expected_output: bool) =
  name >:: (fun _ -> 
      assert_equal (Action.check_uno lst)  (expected_output))

let action_tests = [
  no_empties_test "testing no empties" dropred1 [] (["drop"; "red"; "1"]|>List.rev);
  parse_test "testing parse drop" "drop Green 2" (Drop ["Green";"2"]); 
  parse_test "testing parse drop uppercase" "DROP Green 2" (Drop ["Green";"2"]); 
  parse_test "testing parse draw " "Draw" Draw; 
  parse_test_exn "testing parse cmdnotfound " "fjjds" CmdNotFound; 
  parse_test_exn_empty "testing parse empty" "" Unavailable;
  check_uno_test "checking uno condition false" ["Drop"; "Green"; "2"] false;
  check_uno_test "checking uno condition true" ["Drop"; "Green"; "2"; "uno"] true;
  check_uno_test "checking uno condition case" ["Drop"; "Green"; "2"; "UNO"] true;
]

let test_state= Gamestate.testing_initializer 2 2 "asc" 1 [List.nth Uno.cards 4]
    ["Wild Card Draw 4"; "Wild Card"; "Yellow Reverse"; "Green Skip";
     "Blue Draw 2"; "Red 1"] 
    ["Blue 1";"Blue Reverse"; "Wild Card Draw 4"; 
     "Red Skip"; "Green Draw 2"; "Red 0";
     "Blue 1"] [] [] [] [] 0 

let test_state_co= Gamestate.testing_initializer 2 3 "asc" 2 [List.nth Uno.cards 4]
    ["Wild Card Draw 4"; "Wild Card"; "Yellow Reverse"; "Green Skip";
     "Blue Draw 2"; "Red 1"] 
    ["Blue 1";"Red Reverse"; "Wild Card Draw 4";  "Red Skip"; "Green Draw 2"; "Red 0";
     "Blue 1"] 
    ["Red 2" ; "Green 0"] [] [] [] 0

let test_state2= Gamestate.testing_initializer 2 2 "asc" 2 [List.nth Uno.cards 30]
    ["Wild Card Draw 4"; "Wild Card"; "Yellow Reverse"; "Green Skip";
     "Blue Draw 2"; "Red 1"] 
    ["Blue Reverse"; "Wild Card Draw 4"; "Red Skip"; "Green Draw 2"; "Red 0";
     "Blue 1"] [] [] [] [] 0


let must_draw= Gamestate.testing_initializer 2 3 "asc" 2 [List.nth Uno.cards 4]
    [] ["Green Reverse"] [] [] [] [] 0

let current_card_name_test
    (name:string)
    (st:Gamestate.t)
    (expected_output: string) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.current_card_name st)  (expected_output))

let take_out_one_test
    (name:string)
    (card_name:string)
    (card_hand: string list)
    (acc:string list)
    (expected_output: string list) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.take_out_one card_name card_hand acc)  (expected_output))

let check_valid_test
    (name:string)
    (card_name:string)
    (deck: string list)
    (st:Gamestate.t)
    (expected_output: bool) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.check_valid card_name deck st) (expected_output))

let cycle_test
    (name:string)
    (current_turn:int)
    (direction: string )
    (numplayers:int)
    (gamest: int)
    (expected_output: int) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.cycle current_turn direction numplayers gamest)  (expected_output))

let cycle_skip_test
    (name:string)
    (current_turn:int)
    (direction: string )
    (numplayers:int)
    (gamest: int)
    (expected_output: int) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.cycle_skip current_turn direction numplayers gamest)(expected_output))

let whose_deck_test
    (name:string)
    (turn:int)
    (st: Gamestate.t)
    (expected_output: string list) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.whose_deck turn st) (expected_output))

let get_state legaloft=
  match legaloft with
  |Legal t->t
  |_->failwith ""

let drop_test_deck
    (name:string)
    (card_name:string)
    (st: Gamestate.t)
    (expected_output: Gamestate.t) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.drop card_name st|>get_state) (expected_output))

let draw_test
    (name:string)
    (st: Gamestate.t)
    (expected_output: int) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.draw st|>get_state|>player_one|>List.length) (expected_output))

let draw_two_test_length
    (name:string)
    (card_name:string)

    (st: Gamestate.t)
    (expected_output: int) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.draw_two card_name st|>get_state|>player_one|>List.length) (expected_output))

let skip_turn_test
    (name:string)
    (card_name:string)
    (st: Gamestate.t)
    (expected_output: int) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.turn_skip card_name st|>get_state|>current_turn) (expected_output))

let turn_rev_test
    (name:string)
    (card_name:string)
    (st: Gamestate.t)
    (expected_output: int) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.turn_reverse card_name st|>get_state|>current_turn) (expected_output))

let wc_test
    (name:string)
    (color_name:string)
    (st: Gamestate.t)
    (expected_output: string ) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.wild_card color_name st|>get_state|>current_card_name) (expected_output))

let wcd4_test_length
    (name:string)
    (color_name:string)
    (st: Gamestate.t)
    (expected_output: int ) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.draw_four color_name st|>get_state|>player_two|>List.length) (expected_output))

let vscomputer_test 
    (name:string)
    (st: Gamestate.t)
    (vs_player_traverse:string list)
    (expected_output: string ) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.vscomputer st vs_player_traverse|>get_state|>current_card_name) (expected_output))

let vscomputer_test_draw
    (name:string)
    (st: Gamestate.t)
    (vs_player_traverse:string list)
    (expected_output: int ) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.vscomputer st vs_player_traverse|>get_state|>player_two|>List.length) (expected_output))

let draw_two_uno_test 
    (name:string)
    (card_name:string)
    (st: Gamestate.t)
    (expected_output: int ) =
  name >:: (fun _ -> 
      assert_equal (Gamestate.draw_two_uno card_name st|>get_state|>player_one|>List.length) (expected_output))

let gamestate_tests = [
  current_card_name_test "testing current card" test_state "Red 1";
  take_out_one_test "testing take out one" "Blue 1" (card_list_to_card_name_list cardlist2 )
    [] ((card_list_to_card_name_list (cardlist2) )|> List.tl);
  check_valid_test "not in deck drop" "Green Draw 2" (player_one test_state) test_state false;
  check_valid_test " valid drop matching num" "Blue 1" (player_two test_state) test_state true;
  check_valid_test "valid drop matching color" "Red Skip" (player_two test_state) test_state true;
  cycle_test "no comp player, asc 3 players wrap" 3 "asc" 3 2 1;
  cycle_test "no comp player, asc 3 players std " 1 "asc" 3 2 2;
  cycle_test "no comp player, asc 4 players wrap " 4 "asc" 4 2 1;
  cycle_test "no comp player,des 4 players wrap" 1 "des" 4 2 4;
  cycle_test "no comp player, 4 players std" 2 "des" 4 2 1;
  cycle_test "comp player, asc 3 players wrap"  5 "asc" 3 1 1;
  cycle_test "comp player, asc 3 players jump" 2 "asc" 3 1 5;
  cycle_test "comp player, asc 2 players jump" 1 "asc" 2 1 5;
  cycle_test "comp player, asc 5 players wrap" 5 "asc" 5 1 1;
  cycle_test "comp player, des 3 players jump" 5 "des" 3 1 2;
  cycle_test "comp player, des 3 players wrap" 1 "des" 3 1 5;
  cycle_test "comp player, des 4 players std" 4 "des" 4 1 3;
  cycle_skip_test "skip, no comp player, asc 2 players" 1 "asc" 2 2 1;
  cycle_skip_test "skip, no comp player, asc 3 players std" 1 "asc" 3 2 3;
  cycle_skip_test "skip, no comp player, asc 3 players wrap" 3 "asc" 3 2 2;
  cycle_skip_test "skip, no comp player, des 3 players" 1 "des" 3 2 2;
  cycle_skip_test "skip, no comp player, des 4 players std" 4 "des" 4 2 2;
  cycle_skip_test "skip, comp player, asc 3 players std" 1 "asc" 3 1 5;
  cycle_skip_test "skip, comp player, asc 3 players wrap" 2 "asc" 3 1 1;
  cycle_skip_test "skip, comp player, asc 4 players std" 3 "asc" 4 1 1;
  cycle_skip_test "skip, comp player, asc 2 players std" 1 "asc" 2 1 1;
  cycle_skip_test "skip, comp player, asc 2 players std" 5 "asc" 2 1 5;
  cycle_skip_test "skip, comp player, asc 5 players std" 1 "asc" 5 1 3;
  cycle_skip_test "skip, comp player, asc 5 players wrap" 4 "asc" 5 1 1;
  cycle_skip_test "skip, comp player, des 3 players wrap" 1 "des" 3 1 2;
  cycle_skip_test "skip, comp player, des 4 players jump" 5 "des" 4 1 2;
  cycle_skip_test "skip, comp player, des 5 players std" 5 "des" 5 1 3;
  cycle_skip_test "skip, comp player, des 4 players wrap" 2 "des" 4 1 5;
  whose_deck_test "whose deck test" 1 test_state ["Wild Card Draw 4"; "Wild Card"; "Yellow Reverse"; "Green Skip";
                                                  "Blue Draw 2"; "Red 1"];
  whose_deck_test "whose deck test" 2 test_state ["Blue 1";"Blue Reverse"; "Wild Card Draw 4"; "Red Skip"; "Green Draw 2"; "Red 0";
                                                  "Blue 1"];
  drop_test_deck "drop normal card" "Blue 1" test_state2 
    (Gamestate.testing_initializer 2 2 "asc" 1 [List.nth Uno.cards 5]
       ["Wild Card Draw 4"; "Wild Card"; "Yellow Reverse"; "Green Skip";
        "Blue Draw 2"; "Red 1"] 
       (["Blue Reverse"; "Wild Card Draw 4"; 
         "Red Skip"; "Green Draw 2"; "Red 0";
        ]|>List.rev)[] [] [] [] 0);
  draw_test "length of drawing player inc" test_state ((test_state|>player_one
                                                        |>List.length)+1);
  draw_two_test_length "length of next player d2" "Green Draw 2" test_state2 
    6;
  skip_turn_test "testing that skips accurately" "Red Skip" 
    test_state_co 1;
  turn_rev_test "testing if reverse revs" "Red Reverse" test_state_co 1;
  wc_test "wc update current card w/ colorname" "Red" test_state "Red";
  wcd4_test_length "wcd4 adds 4 to next player" "Red" test_state 7;
  vscomputer_test "testing vs automated drop" test_state_co (player_two test_state_co) "Blue 1";
  vscomputer_test_draw "testing vs automated draw" must_draw (player_two must_draw) 2 ;
  draw_two_uno_test "testing adding two cards to current player" "Red 1" test_state 8
]
let suite = "uno test suite" >::: List.flatten [
    uno_tests;
    action_tests;
    gamestate_tests;
  ]

let _ = run_test_tt_main suite