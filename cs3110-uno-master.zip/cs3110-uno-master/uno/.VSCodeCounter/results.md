# Summary

Date : 2019-12-03 14:18:12

Directory /Users/Juliane/Documents/CS 3110/cs3110-uno/uno

Total : 12 files,  922 codes, 104 comments, 142 blanks, all 1168 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| OCaml | 11 | 890 | 101 | 131 | 1,122 |
| Makefile | 1 | 32 | 3 | 11 | 46 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 12 | 922 | 104 | 142 | 1,168 |

[details](details.md)