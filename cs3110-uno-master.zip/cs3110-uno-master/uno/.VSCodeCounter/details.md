# Details

Date : 2019-12-03 14:18:12

Directory /Users/Juliane/Documents/CS 3110/cs3110-uno/uno

Total : 12 files,  922 codes, 104 comments, 142 blanks, all 1168 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Makefile](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/Makefile) | Makefile | 32 | 3 | 11 | 46 |
| [action.ml](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/action.ml) | OCaml | 39 | 9 | 6 | 54 |
| [action.mli](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/action.mli) | OCaml | 16 | 0 | 5 | 21 |
| [authors.ml](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/authors.ml) | OCaml | 1 | 0 | 0 | 1 |
| [authors.mli](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/authors.mli) | OCaml | 1 | 6 | 1 | 8 |
| [gamestate.ml](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/gamestate.ml) | OCaml | 350 | 14 | 43 | 407 |
| [gamestate.mli](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/gamestate.mli) | OCaml | 33 | 0 | 4 | 37 |
| [play.ml](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/play.ml) | OCaml | 174 | 9 | 19 | 202 |
| [play.mli](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/play.mli) | OCaml | 0 | 0 | 1 | 1 |
| [test.ml](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/test.ml) | OCaml | 90 | 34 | 19 | 143 |
| [uno.ml](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/uno.ml) | OCaml | 170 | 28 | 19 | 217 |
| [uno.mli](file:///Users/Juliane/Documents/CS%203110/cs3110-uno/uno/uno.mli) | OCaml | 16 | 1 | 14 | 31 |

[summary](results.md)